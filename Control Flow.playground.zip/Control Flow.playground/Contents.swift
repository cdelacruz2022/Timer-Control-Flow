import UIKit
let Max = 180
for Timer in 0...Max
{
print("\(Timer) seconds")
    if Timer == Max{
        print("Timer Over")
    }
}
